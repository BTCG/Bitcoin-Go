from jsonrpc import ServiceProxy
access = ServiceProxy("http://127.0.0.1:26020")
pwd = raw_input("Enter wallet passphrase: ")
access.walletpassphrase(pwd, 60)